package com.nttpc.voip.bct.testbase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.nttpc.voip.bct.utility.TestUtility;

public class TestBase {
	
	public static WebDriver driver;
	public static Properties prop;
	
	
	public TestBase (){ // test base class constructor
		
		// load propertined file 
		prop = new Properties();
	
		try {
			FileInputStream fileInput = new FileInputStream("..//NTTPCVoIPBCTTest//src//main//java//com//nttpc//voip//bct//config//config.properties");
			//"D:\\Study\\EclipseWorkspaceJuly17\\NTTPCVoIPBCTTest"+ "\\src\\main\\java\\com\\nttpc\\voip\\bct\\config\\config.properties"
			prop.load(fileInput);
		} catch (FileNotFoundException e) {
	
			e.printStackTrace();
		} catch (IOException e) {
	
			e.printStackTrace();
		}
					
	}
	
	public static void browserInitialization(){
		
		String browname =prop.getProperty("browser");
	
		// to initialize firefox browser
   if (browname.equalsIgnoreCase("firefox")){
			
			System.setProperty("webdriver.gecko.driver", ".,//NTTPCVoIPBCTTest//drivers//geckodriver-v0.18.0-win32//geckodriver.exe");
			
			driver = new FirefoxDriver();
						
		} 
		
		//to initilaize chrome browser
		else if(browname.equalsIgnoreCase("chrome"))
		
		{
			System.setProperty("webdriver.chrome.driver","//usr//bin//chromedriver" );
			driver = new ChromeDriver();
						
		}
		
		//to initilaize IE browser
		else if(browname.equalsIgnoreCase("ie"))
        {
			System.setProperty("webdriver.ie.driver","..//drivers//geckodriver-v0.18.0-win32//IEDriverServer.exe");
			driver = new InternetExplorerDriver();
					
		}
   
           driver.manage().window().maximize();
           driver.manage().deleteAllCookies();
           driver.manage().timeouts().pageLoadTimeout(TestUtility.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
           driver.manage().timeouts().implicitlyWait(TestUtility.IMPLICIT_WAIT, TimeUnit.SECONDS);
           driver.get(prop.getProperty("url")); 
   			
	}
	
	
	
	
	
	

}
