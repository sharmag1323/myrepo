package com.nttpc.voip.bct.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.nttpc.voip.bct.testbase.TestBase;

public class LoginPage extends TestBase {
	
	// Login Page Factory - OR
	
	
	@FindBy(id="loginName")
	WebElement usrIDTxtBx;
	
	@FindBy(id="loginPwd")
	WebElement usrPwdTxtBx;
	
	@FindBy(xpath=".//*[@id='loginForm']/div/button")
	WebElement signINBtn;
	
	
	//Login Page Methods
	public LoginPage(){
		PageFactory.initElements(driver, this);
		
	}
	
	public void userLogin(String usrNme, String usrPwd) {
		
		usrIDTxtBx.sendKeys(usrNme);
		usrPwdTxtBx.sendKeys(usrPwd);
		signINBtn.click();
				
	}
	
	public void loginPageTitle(){
		
	String loginPgTitle = driver.getTitle();
	Assert.assertEquals(loginPgTitle, "VoIP | Home");
		
	}
	
	
	

}
