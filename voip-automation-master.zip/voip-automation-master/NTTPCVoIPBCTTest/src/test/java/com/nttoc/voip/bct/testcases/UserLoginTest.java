package com.nttoc.voip.bct.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nttpc.voip.bct.pages.LoginPage;
import com.nttpc.voip.bct.testbase.TestBase;


public class UserLoginTest extends TestBase {

	LoginPage loginPg;
	
	public UserLoginTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		browserInitialization();
		
		loginPg = new LoginPage();
		
	}
		
	@Test(priority=1)
	
	public void loginPgTitleTestcase(){
		loginPg.loginPageTitle();
	}
	
	@Test(priority=2)
	
	public void userLoginTestcase() {
		
		loginPg.userLogin(prop.getProperty("username"), prop.getProperty("password"));
		
	}
		
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	
	
}
